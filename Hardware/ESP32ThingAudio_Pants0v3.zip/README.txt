ESP32 Thing Audio Pants

An audio codec add on board for the Sparkfun ESP32 Thing. Uses the NXP SGTL5000 low power audio IC and provides connections for a single 18650 Battery to be mounted on the back of the board. The schematic is pretty much just an adapted Teensy Audio Board minus the SD card and extras.

Main intent of the project is to connect from my phone/computer via bluetooth, stream audio to the esp32 thing and connect my normal 3.5mm jack headphones up to the board so essentially you can turn any headphones into "wireless" headphones.
